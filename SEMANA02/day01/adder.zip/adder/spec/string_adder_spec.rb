require_relative '../app/string_adder.rb'

RSpec.describe StringAdder do

end
