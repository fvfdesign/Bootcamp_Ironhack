class StrignAdder


end
