class Sandwich < ActiveRecord::Base
	has_many :sandwich_ingredients
	has_many :ingredients, :through => :sandwich_ingredients

	def as_json(options={})
		super(
			except: [:created_at, :updated_at],
			include: [ingredients: {only: [:name, :calories]}]
			)
	end

	# def add(ingredient)
	# 	self.push(ingredient)		
	# 	# self.save
	# end not neccassary. we could make the push directly in the controller.

end
