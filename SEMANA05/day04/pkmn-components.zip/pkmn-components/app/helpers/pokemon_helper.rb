module PokemonHelper
end
